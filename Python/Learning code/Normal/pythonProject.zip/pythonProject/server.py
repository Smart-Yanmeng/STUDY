import socket
import numpy as np
import time

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

host = socket.gethostname()
port = 12345

server_socket.bind((host, port))

server_socket.listen(5)

while True:
    client_socket, addr = server_socket.accept()
    print(f"ADDRESS -> {str(addr)}")

    while True:
        start_time = time.time()
        data = client_socket.recv(8 * 1000000)
        end_time = time.time()

        received_matrix = np.frombuffer(data, dtype=np.float64).reshape((1000000, 1))

        print(received_matrix)
        print(f"TIME -> {str(end_time - start_time)}")

    client_socket.close()
