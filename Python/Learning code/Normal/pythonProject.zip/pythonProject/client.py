import socket
import time

import numpy as np

timeArr = np.array([])

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

host = socket.gethostname()
port = 12345

client_socket.connect((host, port))

matrix = np.random.rand(1000000, 1)
print(matrix)

for i in range(10000):
    print(i)
    start_time = time.time()
    client_socket.send(matrix.tobytes())
    end_time = time.time()
    useTime = end_time - start_time
    timeArr = np.append(timeArr, useTime)

print(f"TIME -> {np.mean(timeArr)}")

client_socket.close()
